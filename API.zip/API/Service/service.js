const Repository = require('./../Repository');

class Service {
    constructor() {
        this.Repository = new Repository();
    }

    async getAllApplications() {
        return await this.Repository.getApplications([], null);
    }

    async getApplicationByName(applicationName) {
        return await this.Repository.getApplication(applicationName);
    }

    async getAllComputeResources() {
        return await this.Repository.getComputeResources([], null);
    }

    async getComputeResourceByName(resourceName) {
        return await this.Repository.getComputeResource(resourceName);
    }
    
}

module.exports = Service;
