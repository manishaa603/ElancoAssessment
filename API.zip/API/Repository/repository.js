let AWS = require("aws-sdk");
const applicationTableName = process.env.ApplicationTableName;

class Repository {
    constructor() {
        this.docClient = new AWS.DynamoDB.DocumentClient({ region: "us-east-1" });
        this.ec2 = new AWS.EC2();
    }

    async getApplications(applicationList, exclusiveStartKey) {
        try {
            let params = {
                TableName: applicationTableName
            }
            if (exclusiveStartKey)
                params.ExclusiveStartKey = exclusiveStartKey;
            let data = await this.docClient.scan(params).promise();
            applicationList = applicationList.concat(data.Items);
            if (data.LastEvaluatedKey)
                return await this.getApplications(applicationList, data.LastEvaluatedKey);
            return applicationList;
        } catch (error) {
            console.log("error ", error);
            throw error;
        }
    }

    async getApplication(applicationName) {
        try {
            let params = {
                TableName: applicationName,
                Key: {
                    ApplicationName: applicationName
                }
            };
            let data = await this.docClient.get(params).promise();
            return data.Item;
        } catch (error) {
            console.log("error ", error);
            throw error;
        }
    }

    async getComputeResources(resourceList, nextToken) {
        try {
            let params={};
            if(nextToken)
                params.NextToken = nextToken;
            let data = await this.ec2.describeInstances(params);
            resourceList = resourceList.concat(data.Reservations);
            if(data.NextToken)
                return await this.getComputeResources(resourceList, data.NextToken);
            return resourceList;
        } catch (error) {
            console.log("error ", error);
            throw error;
        }
    }

    async getComputeResource(resourceName) {
        try {
            let params = {
                Filters: [{
                    Name: "tag:Name",
                    Values: [
                        resourceName
                    ]
                }]
            };
            return await this.ec2.describeInstances(params).promise();
        } catch (error) {
            console.log("error ", error);
            throw error;
        }
    }
}
module.exports = Repository;
