class InternalError extends Error {
    constructor(message){
        super(message);
        Error.captureStackTrace(this, this.constructor); 
    }
}

// all business related errors
class BusinessError extends InternalError {
    constructor(message){
        super(message);
        this.name = this.constructor.name;
        this.statusCode = 500;
    }
}

// all validation errors
class ValidationError extends BusinessError {
    constructor(message){
        super(message);
        this.statusCode = 400;
    }
}

module.exports = {
    InternalError: InternalError,
    BusinessError: BusinessError,
    ValidationError: ValidationError
}

