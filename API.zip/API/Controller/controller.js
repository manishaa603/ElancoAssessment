const Service = require("./../Service");
const util = require("./../Util");

class Controller {
  constructor() {
    this.Service = new Service();
  }

  async getAllApplications(req, res) {
    try {
      let data = await this.Service.getAllApplications();
      util.sendSuccessResponse(res, data);
    } catch (err) {
      let error = util.errorResponse(err);
      console.log("Error Response", error);
      res.status(error.statuscode).send(error);
    }
  }

  async getApplicationByName(req, res) {
    try {
      let applicationName = req.query.applicationName;
      let data = await this.Service.getApplicationByName(applicationName);
      util.sendSuccessResponse(res, data);
    } catch (err) {
      let error = util.errorResponse(err);
      console.log("Error Response", error);
      res.status(error.statuscode).send(error);
    }
  }

  async getAllComputeResources(req, res) {
    try {
      let data = await this.Service.getAllComputeResources();
      util.sendSuccessResponse(res, data);
    } catch (err) {
      let error = util.errorResponse(err);
      console.log("Error Response", error);
      res.status(error.statuscode).send(error);
    }
  }

  async getComputeResourceByName(req, res) {
    try {
      let resourceName = req.query.resourceName;
      let data = await this.Service.getComputeResourceByName(resourceName);
      util.sendSuccessResponse(res, data);
    } catch (err) {
      let error = util.errorResponse(err);
      console.log("Error Response", error);
      res.status(error.statuscode).send(error);
    }
  }
}

module.exports = Controller;
