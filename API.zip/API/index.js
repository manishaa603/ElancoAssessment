//const api = require("express")();
const api = require('lambda-api')({ logger: true });
const util = require('./Util');
const Controller = require('./Controller');
const controller = new Controller();
//const PORT = 8080;
/*api.listen(PORT, ()=>{
    console.log(`Server running on http://localhost:${PORT}`);
});*/

api.get('/raw', async (req, res)=>{
    let respObj = { status: "ok" };
    util.sendSuccessResponse(res, respObj);
})

api.get('/applications', async(req, res)=>{
    await controller.getAllApplications(req, res);
})

api.get('/application/:applicationName', async (req, res)=>{
    await controller.getApplicationByName(req, res);
})

api.get('/resources', async (req, res)=>{
    await controller.getAllComputeResources(req, res);
})

api.get('/resource/:resourceName', async (req, res)=>{
    await controller.getComputeResourceByName(req, res);
})

// Declare your Lambda handler
exports.handler = async (event, context) => {
    return await api.run(event, context)
}