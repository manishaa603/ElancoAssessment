const errorResponse = function(err) {
    let httpErrResp = {
        success: false,
        name:err.name,
        message: err.message,
        statuscode: err.statusCode ? err.statusCode: 500
    };
    return httpErrResp;
};

const sendSuccessResponse = function(res, resData) {
    console.log("Successful response:",resData);
    res.status(200).send(resData);
}

module.exports.sendSuccessResponse = sendSuccessResponse;
module.exports.errorResponse = errorResponse;
